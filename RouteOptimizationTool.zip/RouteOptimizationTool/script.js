 var map = L.map('map').setView([12.9716, 77.5946], 7);

L.tileLayer.provider('OpenStreetMap.Mapnik').addTo(map);

// Initialize routing control
var control = L.Routing.control({
    routeWhileDragging: true
}).addTo(map);

// Function to optimize the route
function optimizeRoute() {
    var fromInput = document.getElementById('fromInput').value;
    var toInput = document.getElementById('toInput').value;

    if (!fromInput || !toInput) {
        alert('Please enter both starting location and destination.');
        return;
    }

    // Geocode the input addresses to get the latitude and longitude
    geocodeAddress(fromInput, function (fromLatLng) {
        geocodeAddress(toInput, function (toLatLng) {
            // Set waypoints for routing control
            control.setWaypoints([
                L.latLng(fromLatLng),
                L.latLng(toLatLng)
            ]);

            // Optimize the route
            control.route();
        });
    });
}

// Function to reset the map
function resetMap() {
    // Reset the map to the initial view and clear waypoints
    map.setView([12.9716, 77.5946], 7);
    control.setWaypoints([]);
}

// Function to geocode an address and get its coordinates
function geocodeAddress(address, callback) {
    var apiKey = '8a0dd7b85af349e494182e8520a856f8'; // Replace with your OpenCage API key
    var apiUrl = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(address)}&key=${apiKey}`;

    // Use the OpenCage Geocoding API to get the coordinates based on the address
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.results.length > 0) {
                var coordinates = [data.results[0].geometry.lat, data.results[0].geometry.lng];
                callback(coordinates);
            } else {
                console.error('Error: No results found for the provided address.');
            }
        })
        .catch(error => console.error('Error:', error));
}
